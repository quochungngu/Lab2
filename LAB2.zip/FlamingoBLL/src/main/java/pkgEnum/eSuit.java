package pkgEnum;

public enum eSuit {
	HEARTS, CLUBS, DIAMONDS, SPADES;
}
