package pkgCore;

import pkgEnum.*;
import java.util.ArrayList;
import java.util.Collections;

public class Deck {

	// Add 'cards' attribute that is an ArrayList of Card
	private ArrayList<Card> cards = new ArrayList<Card>();

	// Add a contructor that passes in the number of decks, and then populates
	// ArrayList<Card> with cards (depending on number of decks).
	public Deck(int NumDecks) {
		for (; NumDecks > 0; NumDecks--) {
			for (eRank eRank : eRank.values()) {
				for (eSuit eSuit : eSuit.values()) {
					cards.add(new Card(eSuit, eRank));
				}
			}
		}
		Collections.shuffle(cards);
	}

	// Add a draw() method that will take a card from the deck and
	// return it to the caller
	public Card draw() {
		return cards.remove(0);
	}
}
