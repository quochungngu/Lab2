package pkgCore;

import pkgEnum.*;

public class Card implements Comparable {

	// Card has two attributes, eRank and eSuit, add these attributes
	public eRank eRank;
	public eSuit eSuit;

	// Build a constructor for Card passing in eRank and eSuit
	public Card(eSuit Suit, eRank Rank) {
		seteRank(Rank);
		seteSuit(Suit);
	}

	public Card() {

	}

	// Add a public 'getter' method for eRank and eSuit.
	// Add a private 'setter' method for eRank and eSuit

	public eRank geteRank() {
		return eRank;
	}

	private void seteRank(eRank Rank) {
		eRank = Rank;
	}

	public eSuit geteSuit() {
		return eSuit;
	}

	private void seteSuit(eSuit Suit) {
		eSuit = Suit;
	}

	@Override
	public int compareTo(Object o) {
		Card c = (Card) o;
		return c.geteRank().compareTo(this.geteRank());
	}
}
