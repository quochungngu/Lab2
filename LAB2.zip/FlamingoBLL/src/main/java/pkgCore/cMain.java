package pkgCore;

import pkgEnum.*;

public class cMain {

	public static void main(String[] args) {

		Hand h = new Hand();
		System.out.println(h.ScoreHand());
	}
}
